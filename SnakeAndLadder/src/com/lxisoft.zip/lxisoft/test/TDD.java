package com.lxisoft.test;

import com.lxisoft.snakeandladder.Game;
public class TDD{
	public static void main(String[] args){
		Game game=new Game();
		game.userInterface();
		
	}
}