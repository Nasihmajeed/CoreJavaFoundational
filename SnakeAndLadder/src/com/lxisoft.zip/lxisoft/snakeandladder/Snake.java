package com.lxisoft.snakeandladder;
import java.util.Scanner;
public class Snake{


		

	

	}
	


