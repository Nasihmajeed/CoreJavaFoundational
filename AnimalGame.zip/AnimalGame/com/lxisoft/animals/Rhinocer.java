package com.lxisoft.animals;

import com.lxisoft.game.Animal;

public class Rhinocer extends Animal implements Herbivores {

public Rhinocer() {

super();

}

public Rhinocer(String animalName, String eat , int strengthLevel, int hungeryLevel) {

super(animalName, eat, strengthLevel, hungeryLevel);

}

}