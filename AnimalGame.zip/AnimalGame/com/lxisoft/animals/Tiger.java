package com.lxisoft.animals;

import com.lxisoft.game.Animal;

public class Tiger extends Animal implements Carnivores {

public Tiger() {

super();

}

public Tiger(String animalName, String eat , int strengthLevel, int hungeryLevel) {

super(animalName, eat, strengthLevel, hungeryLevel);

}

}

