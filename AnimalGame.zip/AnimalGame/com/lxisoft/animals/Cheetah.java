package com.lxisoft.animals;

import com.lxisoft.game.Animal;

public class Cheetah extends Animal implements Carnivores {

public Cheetah() {

super();

}

public Cheetah(String animalName, String eat , int strengthLevel, int hungeryLevel) {

super(animalName, eat, strengthLevel, hungeryLevel);

}

}