package com.lxisoft.animals;

import com.lxisoft.game.Animal;

public class Zebra extends Animal implements Herbivores {

public Zebra() {

super();

}

public Zebra(String animalName, String eat , int strengthLevel, int hungeryLevel) {

super(animalName, eat, strengthLevel, hungeryLevel);

}

}