package com.lxisoft.animals;

import com.lxisoft.game.Animal;

public class Lion extends Animal implements Carnivores {

public Lion() {

super();

}

public Lion(String animalName, String eat , int strengthLevel, int hungeryLevel) {

super(animalName, eat, strengthLevel, hungeryLevel);

}

}
