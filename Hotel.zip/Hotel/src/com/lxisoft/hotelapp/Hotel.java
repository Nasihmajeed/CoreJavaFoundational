package com.lxisoft.hotelapp;
public class Hotel
{
	Menu menu=new Menu();
public void printHotel()
     {
      
    System.out.println("       ************************************************************************");
    System.out.println("       *                                                                      *");
    System.out.println("       *                          Top Chicken                                 *");   
    System.out.println("       *                    Multi Cuisine Restuarent                          *");
    System.out.println("       *         Mele Pattambi, Palakkad Road, Near juma Masjid               *");
    System.out.println("       *                                                                      *");
    System.out.println("       ************************************************************************");
    System.out.println("");
   System.out.println("");
}
public void printDetail()
{
	menu.printMenu();
}
}
   
