package com.lxisoft.hotelapp;
import java.util.Scanner;
public class Order
{
	
}