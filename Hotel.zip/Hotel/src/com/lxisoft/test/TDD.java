package com.lxisoft.test;
import com.lxisoft.hotelapp.Hotel;

 public class TDD{

 	public static void main(String[] arrays){
 		Hotel hotel=new Hotel();
 		hotel.printHotel();
		hotel.printDetail();
 		
 	}
 }