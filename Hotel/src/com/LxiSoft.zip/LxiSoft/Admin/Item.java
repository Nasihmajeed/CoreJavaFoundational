package com.LxiSoft.Admin;
import com.LxiSoft.Hotel.Hotel;
public class Item
{
	public void editMenu()
	{

}	
}