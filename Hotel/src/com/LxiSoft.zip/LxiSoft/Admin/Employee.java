package com.LxiSoft.Admin;
public class Employee
{
	public void employDetails()
	{

	}
}
