package com.LxiSoft.Test;
import com.LxiSoft.Hotel.Hotel;
public class Tdd
{
	public static void main (String array[])
{
	Hotel hotel=new Hotel();
	hotel.printHotel();
	hotel.printDetail();
}
}
