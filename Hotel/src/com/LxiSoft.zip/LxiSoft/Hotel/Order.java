package com.LxiSoft.Hotel;
import java.util.Scanner;
import com.LxiSoft.Admin.Admin;
public class Order
{
         Scanner scnr = new Scanner(System.in);
        Menu menu=new Menu();
        public void getOrder()
         {
    
 ArrayList<Item>billPrint = new ArrayList<Item>();
 for(int i=0;i<theMenu.size();i++)
{
  billPrint.add(theMenu.get(i));
}
}
        }
    