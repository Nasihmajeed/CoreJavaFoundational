package com.LxiSoft.Hotel;
import java.util.Scanner;
public class Item extends Dinner
{
	
}