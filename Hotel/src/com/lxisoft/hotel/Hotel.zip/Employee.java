package com.lxisoft.hotel;
import java.util.Scanner;

public class Employee{
	String empName;
}