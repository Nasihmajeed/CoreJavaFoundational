package com.lxisoft.hotel;
import java.util.Scanner;

public class Admin{

	Bill bill[]=new Bill();
	String adminName;
}