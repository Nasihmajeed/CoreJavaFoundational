package com.lxisoft.hotel;
import java.util.Scanner;
public class Vegbiriyani{
	int vbPrize=100;
	String vbName= "VEG BIRIYANI";
}