package com.lxisoft.hotel;
import java.util.Scanner;
public class Regularmeals{
	int rmPrize=70;
	String rmName="REGULAR MEALS";
}