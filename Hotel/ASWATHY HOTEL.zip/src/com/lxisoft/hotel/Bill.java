package com.lxisoft.hotel;
import java.util.Scanner;
public class Bill{
	int total;

	public void printBillDetails(){

		System.out.println("The total bill is");
	}
	
}