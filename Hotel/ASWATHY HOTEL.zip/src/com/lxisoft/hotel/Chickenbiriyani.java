package com.lxisoft.hotel;
import java.util.Scanner;
public class Chickenbiriyani{
	int cbPrize=100;
	String cbName="CHICKEN BIRIYANI";
}