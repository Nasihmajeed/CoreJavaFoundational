package com.lxisoft.test;
import com.lxisoft.hotel.Hotel;
 public class TDD{

 	public static void main(String[] args){
 		Hotel hotel=new Hotel();
 		hotel.printHotelDetails();
 		
 	}
 }