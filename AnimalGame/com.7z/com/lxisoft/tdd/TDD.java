 //Packages

package com.lxisoft.tdd;
import com.lxisoft.forest.Animal;
import com.lxisoft.forest.Forest; 
import java.util.ArrayList;
import java.util.List;

public class TDD {
	public static void main (String [] args) {
		
		List<Animal> animals = new ArrayList<Animal>();
		
		Forest denseForest=new Forest();
		
		Forest Animal=new Forest();
		 
 	/* 		 Animal animal1 = new Animal();
			animal1.setAnimalName("Tiger");
			animal1.setAnimalStrengthLevel(100);
			animal1.setAnimalHungerLevel(80);
			animal1.setAnimalAggressivenessLevel(70); */
						
			Animal animal2 = new Animal();
			animal2.setAnimalName("Lion");
			animal2.setAnimalStrengthLevel(90);
			animal2.setAnimalHungerLevel(90);
			animal2.setAnimalAggressivenessLevel(50);
			
			Animal animal3 = new Animal();
			animal3.setAnimalName("CHEETAH");
			animal3.setAnimalStrengthLevel(50);
			animal3.setAnimalHungerLevel(85);
			animal3.setAnimalAggressivenessLevel(750); 
			
			
		// Fight Between "ANIMALS(TIGER, LION & CHEETAH)"
		
			//Forest.animal1.animalFight(animal2);		
			animal2.animalFight(animal3);
			//animal3.animalFight(animal1);
					
		// Printing Sections Forest Details		

		denseForest.setForestName("\n"+"Forest Name : Amazon Forest");
		System.out.println(denseForest.getForestName()+"\n");
		
		// Printing Sections Animals Details
		
/* 		System.out.println("____TIGER DETAILS_____\n");
		System.out.println("AnimalName: "+animal1.getAnimalName()
		+"\nAnimalStrengthLevel: "+animal1.getAnimalStrengthLevel()
		+"\nAnimalHungerLevel: "+animal1.getAnimalHungerLevel()
		+"\nAnimalAggressivenessLevel: "+animal1.getAnimalAggressivenessLevel()+"\n"); */
		
		System.out.println("____LION DETAILS_____\n");
		System.out.println("AnimalName: "+animal2.getAnimalName()
		+"\nAnimalStrengthLevel: "+animal2.getAnimalStrengthLevel()
		+"\nAnimalHungerLevel: "+animal2.getAnimalHungerLevel()
		+"\nAnimalAggressivenessLevel: "+animal2.getAnimalAggressivenessLevel());
		
				System.out.println("____CHEETAH DETAILS_____\n");
		System.out.println("AnimalName: "+animal3.getAnimalName()
		+"\nAnimalStrengthLevel: "+animal3.getAnimalStrengthLevel()
		+"\nAnimalHungerLevel: "+animal3.getAnimalHungerLevel()
		+"\nAnimalAggressivenessLevel: "+animal3.getAnimalAggressivenessLevel());
		
		//// Printing Sections Fight Details
		
/* 		System.out.println("\n"+"Tiger's damage: "+animal1.getDamagePercentage()
		+"\nLion's Damage:"+animal2.getDamagePercentage()+"\n"); */
		
		System.out.println("Lion's damage: "+animal2.getDamagePercentage()
		+"\nCheetah's Damage:"+animal3.getDamagePercentage()+"\n");
		
/* 		System.out.println("Cheetah's damage: "+animal3.getDamagePercentage()
		+"\nTiger's Damage:"+animal1.getDamagePercentage()+"\n"); */
		
				
	}
}