package com.lxisoft.animals;

import com.lxisoft.game.Animal;

public interface Herbivorous {

    public  void escapeFromEnemy(Animal player1); 
     

      }



