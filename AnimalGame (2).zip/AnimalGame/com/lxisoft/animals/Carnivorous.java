package com.lxisoft.animals;

import com.lxisoft.game.Animal;

public interface Carnivorous {

    public void startFight(Animal opponent);
    

    }


