package com.lxisoft.test;
import com.lxisoft.game.Forest;
import com.lxisoft.game.Animal;


public class Tdd {

public static void main(String[] args) {

Forest forest = new Forest();

forest.welcomeToForest();

}

}