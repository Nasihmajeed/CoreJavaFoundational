

public class Teacher extends Students
{
	String teacher1, teacher2;
	String subject1,subject2;
	public String teacherDetail1()
		{
			return teacher1;
			
		}



		public String subject1Detail()
		{
			return subject1;
		}



	
	public String teacherDetail2()
	{
		return teacher2;
		
	}



	public String subject2Deatail()
	{
		return subject2;
	}
}