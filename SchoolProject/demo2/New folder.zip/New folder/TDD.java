
public class TDD
{
	public static void main(String args[])
	{
		
		School h = new School();
		h.schoolname = "Donbosco";
		h.class1="10A";
		h.class2="10B";
		
		h.teacher1="Mary";
		h.subject1="English";

		h.teacher2="Saraswathi";
		h.subject2="Maths";

		h.student1 = "Akil";
		h.student2 = "Jamal";
		
		h.Printdetail();

		h.m1=45;
		h.m2=40;
		h.m3=42;

		h.n1=30;
		h.n2=20;
		h.n3=35;

		h.l1=23;
		h.l2=44;
		h.l3=34;

		h.p1=33;
		h.p2=44;
		h.p3=12;

		h.Total();
	};
}
		
