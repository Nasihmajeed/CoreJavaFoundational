

public class Students
{
	String student1,student2;
	int m1,m2,m3;
	int n1,n2,n3;
	int l1,l2,l3;
	int p1,p2,p3;
	int t1,t2,t3,t4;

	public String studentDetail1()
		{
			return student1;

		}
	
	public String studentDetail2()
	{
		return student2;

	}
		
}