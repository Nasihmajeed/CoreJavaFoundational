

public class Classroom extends Teacher
{
	String class1, class2;
		public String classDetail1()
		{
			return class1;
		}
		
		public String classDetail12()
		{
			return class2;
		}
		
		
}

